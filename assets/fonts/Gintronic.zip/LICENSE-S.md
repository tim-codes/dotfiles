
# Gintronic

By Mark Frömberg

### Your License:
__License S__
*(Up to 3 users)*


# EULA (End User License Agreement)
(https://markfromberg.com/info-eula/)


This End User License Agreement (further referred to as the “Agreement”, “EULA,” “License,” or “License Agreement”) is a legal agreement between a licensee (“You”) and Mark Frömberg. By downloading and/or installing, copying, or using the Font Software, you agree the terms of this Agreement. If You do not agree to these terms, do not purchase this License, or download, or install, or use the Font Software.

Definitions

“Font software” means coded software that generates typeface designs when used with the appropriate hardware and software, plus any and all other data including documentation provided with such software. “Licensed unit” means an installation of the font software that allows up to three (3) concurrent users to use it at a single geographic location. A single geographic location is in particular the site of your place of business. The geographic restriction does not apply to portable computers if they are owned by the end user.

1. Number of users

The license to use a font made by Mark Frömberg can be purchased through Mark Frömberg or any other distributers (e.g. FutureFonts). Upon purchasing a license, the licensee is granted a non-exclusive, non-transferrable right to use the font software in a licensed unit for their own personal or internal business purposes according to the terms of this license. The end user has no rights to the font software other than those expressly set forth in this license. If the number of users who use the font software exceed those set forth in the definition of the licensed unit above, then the end user must request from Mark Frömberg an appropriate license covering all users. An additional fee will be charged for this license extension.

Multiple user licences

The purchase of 1 license grants up to 3 users, of a single organisation, the right to use a copy of the font software. If more than 3 users will be using the font software, you are required to purchase a multi-users license using the following table as a reference. If more user licenses are needed, please get in touch at: hello@markfromberg.com.

2. Requirements and restrictions

A. Embedding, Online Documents And Interactive Media

The licensee may embed the font software in documents, applications or devices either as a rasterised representation of the font software (e.g., a GIF or JPEG file) or as a subset of the font software (e.g., as part of a PDF file) as long as the document, application or device is distributed in a secure format that permits only the viewing and printing but not the editing of the text. The licensee needs an additional OEM license (i) for the use of the font software in documents, applications or devices permitting editing of the text, if such documents, applications or devices shall be distributed to third parties or (ii) if the font software is embedded neither as a subset nor as a rasterised representation (e.g., video games, e-books, apps, media devices like smart phones and e-book readers).

B. Allowed Uses (Media)

The licensee may use the font software to create images on any surface such as computer screens, paper, photographs, printed material, t-shirts, and other surfaces where the image is a fixed size. They may use the font software to create EPS files or other scalable drawings provided that such files are only used by the licensed unit. Any font software made by Mark Frömberg may not be distributed and/or sold to third parties without her prior written consent.

C. Typesetting Products

You may not use the Font to create alphabet or letterform products for resale where the product consists of individual letterforms, including rubber stamps, die-cut products, stencil products, or adhesive sticker alphabet products where the likeness of the Font can be reproduced and the end-user of said products can create their own typesetting. An extended license to produce these may be available for an additional fee.

D. Web Use

The end user is allowed to use the desktop fonts on the web as an image only (non-selectable text). It is prohibited to host a copy of these fonts as a web font on your own website. Please use the provided WOFF2 file for running text on the web (if it isn’t provided, ask for one by getting in touch via email or wait for the next update).

E. Icons, Dingbats And Patterns In Products

You may not use illustrations or images in the Font other than letterforms, numbers, punctuation marks, diacritics, etc., in a manner where the illustration or image becomes the primary aspect of a product for resale. For example, a dingbat image in the font cannot be the sole design element on a coffee cup, t-shirt, greeting card, etc., intended for resale, unless an extended license is acquired at an (affordable) additional fee.

F. Broadcasting

For using the font software in broadcasts, video or film, an additional broadcasting license is needed and needs to be acquired prior to first use. Broadcast and film usage refers to the use of the font software in titling, credits or other text for any onscreen broadcast via television, video or motion picture. The broadcasting license is an annual renewable license extension. Exceptions will be made for art and music videos with a budget under 15.000 Euros.

3. Storage, back-up and printing

The licensee may make back-up copies of the font software for archival purposes only, provided that they retain exclusive custody and control over such copies. The font software may not be installed or used on a server that can be accessed via the internet or other external network system (a system other than a LAN) by workstations which are not part of a licensed unit. The number of output devices is not restricted, provided that these devices do not store the font software permanently.

4. Service bureaus

You may take a digitised copy of the font software used in a particular document to a commercial printer or service bureau for outputting this particular document (this document must not be edited by the printer or service bureau). In the event of any modifications to the document or use of the font software for other purposes, the printer or service bureau must purchase its own font software licenses.

5. Copying

Except as granted in points 2, 3 & 4, the licensee may not copy the font software or allow third parties to copy the font software. Any copy of the font software must contain the same copyright, trademark, and other proprietary information as the originals.

6. Modifications

The licensee may adapt, modify, alter, translate, convert, and install the font software into another format for use in other environments, subject to the following conditions; (a) A computer on which the converted font software is used or installed shall be considered as one of the licensed unit’s permitted number of computers. (b) Usage of the font software that the licensee has converted, shall be pursuant to all the terms and conditions of this license. (c) Such converted font software may be used for the licensee’s own customary internal business or personal use exclusively, and may not be distributed or transferred for any purpose. (d) The licensee may not modify or remove the name(s) of the font software, author’s signature, copyright and trademark notices from the original files.

7. Transfer of license

The licensee may not rent, lease, sublicense, give, lend, or further distribute the font software, parts of it, or any copy thereof, except as expressly provided herein.

8. Ownership and credits

This font software is copyrighted and contains intellectual property information, protected by the laws of the United States of America, by the copyright and design laws of other nations, and by international treaties. The end user agrees that the font software is owned by Mark Frömberg. Its structure, organisation and code are the valuable trade marks of Mark Frömberg. Unauthorised copying of the product even if modified, merged, or included with other software is expressly forbidden. The end user may be held legally responsible for any infringement of the foundry’s intellectual property rights that is caused or encouraged by their failure to abide by the terms of this license agreement. Though not obligatory– to include a colophon or credit the fonts and the designer is always a nice thing to do and is greatly appreciated.

9. Warranty

The foundry or Mark Frömberg cannot be held responsible for any damages caused or supported by the end user and/or third party resulting out of any use of, or inability to use, the font software. Neither is the foundry or Mark Frömberg liable in case of (mis)interpretation of shapes in the fonts, resulting in legal procedures.

10. Termination

The license granted herein is effective until terminated. This agreement shall automatically terminate upon failure by the end user to comply with its terms. Upon termination, the end user must destroy the original and any copies of the software. If any part of this agreement is found void and unenforceable, it will not affect the validity of the agreement, which shall remain valid and enforceable according to its terms.

11. Revocation of Warranties

The Font Software is not fault-tolerant and is not intended and was not designed or manufactured for use in any circumstances where fail-safe operation may be required. the Font Software may not be used in manufacturing, navigation, and process control equipment or in any other circumstances where the use or failure of the Font Software could lead to death, personal injury, property damage or severe physical or environmental damage. Under no circumstances shall Mark Frömberg be liable to you or any other party, whether in contract or tort (including negligence) or otherwise, for any special, consequential, or incidental damages, including lost profits, savings or business interruption as a result of the use of the Font Software even if notified in advance of such possibility. In no event shall any liability of Mark Frömberg exceed the purchase price of the License to the Font Software or replacement of the Font Software, either at Mark Frömberg’s sole discretion.

12. Miscellaneous

The General Terms and Conditions of the customer do not apply.
Should individual provisions of this Agreement be invalid, the validity of the remaining provisions will be unaffected. The contract parties shall make every effort to replace the invalid provision with that valid provision whose economic content most closely approximates to that of the invalid provision.
All the annexes named in this Agreement are binding and integral parts thereof.
The captions and numberings of the sections of this Agreement are for convenience only and shall not control or affect the meaning or construction of any of the terms or provisions of this Agreement.

13. Final provisions

Should individual terms of this license agreement become invalid or unenforceable, all others will remain in full force and effect. Mark Frömberg expressly reserves the right to amend or modify subsequent versions of this license agreement at any time and without prior notification. The end users acknowledge that they have read and understood this license agreement and agree to be bound by its terms and conditions. Lastly, thank you for purchasing font licenses.

Enjoy using the fonts!